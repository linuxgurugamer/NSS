The PNG images in this folder were converted from the DDS textures, solely to
make them available in the Unity editor for configuring the parts' shaders.
They are not the original images.
